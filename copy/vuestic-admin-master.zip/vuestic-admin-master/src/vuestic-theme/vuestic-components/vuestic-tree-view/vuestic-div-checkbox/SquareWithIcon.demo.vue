<template>
  <div
    style="left: 420px; top: 180px; background-color: white; position: absolute"
  >
    <square-with-icon iconClass="ion ion-md-checkmark"/>
  </div>
</template>

<script>
  import SquareWithIcon from './SquareWithIcon.vue'

  export default {
    components: {SquareWithIcon}
  }
</script>
